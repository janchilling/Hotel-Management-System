package com.codegen.hotelmanagementsystembackend.dto;

import lombok.Data;

@Data
public class RefreshTokenRequest {

    private String token;
}
