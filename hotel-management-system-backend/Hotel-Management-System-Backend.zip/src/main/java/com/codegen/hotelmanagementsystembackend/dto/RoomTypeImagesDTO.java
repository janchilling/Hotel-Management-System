package com.codegen.hotelmanagementsystembackend.dto;

import lombok.Data;

@Data
public class RoomTypeImagesDTO {

    private String imageURL;

}
