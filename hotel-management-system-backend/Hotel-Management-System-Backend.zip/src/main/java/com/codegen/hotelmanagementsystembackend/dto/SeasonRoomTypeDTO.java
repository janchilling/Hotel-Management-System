package com.codegen.hotelmanagementsystembackend.dto;

import lombok.Data;

@Data
public class SeasonRoomTypeDTO {

    private Integer seasonId;
    private Double roomTypePrice;
    private Integer noOfRooms;

}
