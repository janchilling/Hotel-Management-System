package com.codegen.hotelmanagementsystembackend.dto;

import lombok.Data;

@Data
public class HotelImageDTO {

    private Long hotelImageId;
    private String hotelImageURL;

}
