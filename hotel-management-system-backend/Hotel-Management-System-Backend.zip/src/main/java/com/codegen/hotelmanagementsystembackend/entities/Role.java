package com.codegen.hotelmanagementsystembackend.entities;

public enum Role {
    CUSTOMER,
    SYSTEM_ADMIN,
}
