package com.codegen.hotelmanagementsystembackend.dto;

import lombok.Data;

@Data
public class HotelPhoneDTO {

    private Long hotelPhoneId;
    private Long hotelPhone;

}
