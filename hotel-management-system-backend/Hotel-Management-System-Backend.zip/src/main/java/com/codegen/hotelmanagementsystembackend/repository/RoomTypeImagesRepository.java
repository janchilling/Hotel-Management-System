package com.codegen.hotelmanagementsystembackend.repository;

import com.codegen.hotelmanagementsystembackend.entities.RoomTypeImages;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomTypeImagesRepository extends JpaRepository<RoomTypeImages, Integer> {
}
