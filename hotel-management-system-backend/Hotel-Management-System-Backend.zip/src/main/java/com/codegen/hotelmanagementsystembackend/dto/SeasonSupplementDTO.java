package com.codegen.hotelmanagementsystembackend.dto;

import lombok.Data;

@Data
public class SeasonSupplementDTO {

    private Double supplementPrice;
    private Integer seasonId;

}
