package com.codegen.hotelmanagementsystembackend.dto;

import lombok.Data;

@Data
public class RoomTypeImagesResponseDTO {

    private Integer roomTypeImageId;
    private String roomTypeImageUrl;

}
