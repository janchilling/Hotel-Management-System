export const environment = {
  production : false,
  firebaseConfig:{
    apiKey: "AIzaSyAmoQJvBKY0F5lL3UaqyxIiR9OiNnSyDNQ",
    authDomain: "hotel-management-system-8c7fb.firebaseapp.com",
    projectId: "hotel-management-system-8c7fb",
    storageBucket: "hotel-management-system-8c7fb.appspot.com",
    messagingSenderId: "12838462475",
    appId: "1:12838462475:web:799569920973581f1e130e",
    measurementId: "G-6L4LWDVR3L"
  }
};
