import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-context',
  templateUrl: './dashboard-context.component.html',
  styleUrls: ['./dashboard-context.component.scss']
})
export class DashboardContextComponent {

}
