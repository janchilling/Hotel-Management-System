import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractSeasonDetailsComponent } from './contract-season-details.component';

describe('ContractSeasonDetailsComponent', () => {
  let component: ContractSeasonDetailsComponent;
  let fixture: ComponentFixture<ContractSeasonDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ContractSeasonDetailsComponent]
    });
    fixture = TestBed.createComponent(ContractSeasonDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
