import { Component } from '@angular/core';

@Component({
  selector: 'app-add-contract-context',
  templateUrl: './add-contract-context.component.html',
  styleUrls: ['./add-contract-context.component.scss']
})
export class AddContractContextComponent {

}
