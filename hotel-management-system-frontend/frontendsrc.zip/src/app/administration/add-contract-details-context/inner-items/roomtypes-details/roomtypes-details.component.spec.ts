import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoomtypesDetailsComponent } from './roomtypes-details.component';

describe('RoomtypesDetailsComponent', () => {
  let component: RoomtypesDetailsComponent;
  let fixture: ComponentFixture<RoomtypesDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RoomtypesDetailsComponent]
    });
    fixture = TestBed.createComponent(RoomtypesDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
