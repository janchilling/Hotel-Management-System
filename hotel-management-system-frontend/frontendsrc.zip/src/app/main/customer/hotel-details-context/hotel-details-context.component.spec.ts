import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelDetailsContextComponent } from './hotel-details-context.component';

describe('HotelDetailsContextComponent', () => {
  let component: HotelDetailsContextComponent;
  let fixture: ComponentFixture<HotelDetailsContextComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HotelDetailsContextComponent]
    });
    fixture = TestBed.createComponent(HotelDetailsContextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
