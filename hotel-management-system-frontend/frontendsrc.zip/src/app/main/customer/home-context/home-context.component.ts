import { Component } from '@angular/core';

@Component({
  selector: 'app-home-context',
  templateUrl: './home-context.component.html',
  styleUrls: ['./home-context.component.scss']
})
export class HomeContextComponent {

}
