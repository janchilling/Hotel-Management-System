import { Component } from '@angular/core';

@Component({
  selector: 'app-home-top-container',
  templateUrl: './home-top-container.component.html',
  styleUrls: ['./home-top-container.component.scss']
})
export class HomeTopContainerComponent {

}
