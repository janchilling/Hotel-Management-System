import { Component } from '@angular/core';

@Component({
  selector: 'app-home-adventure',
  templateUrl: './home-adventure.component.html',
  styleUrls: ['./home-adventure.component.scss']
})
export class HomeAdventureComponent {

}
