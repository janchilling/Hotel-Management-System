import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeTopContainerComponent } from './home-top-container.component';

describe('HomeTopContainerComponent', () => {
  let component: HomeTopContainerComponent;
  let fixture: ComponentFixture<HomeTopContainerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HomeTopContainerComponent]
    });
    fixture = TestBed.createComponent(HomeTopContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
