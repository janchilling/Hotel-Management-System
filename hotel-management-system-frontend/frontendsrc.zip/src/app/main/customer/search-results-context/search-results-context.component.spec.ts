import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchResultsContextComponent } from './search-results-context.component';

describe('SearchResultsContextComponent', () => {
  let component: SearchResultsContextComponent;
  let fixture: ComponentFixture<SearchResultsContextComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SearchResultsContextComponent]
    });
    fixture = TestBed.createComponent(SearchResultsContextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
