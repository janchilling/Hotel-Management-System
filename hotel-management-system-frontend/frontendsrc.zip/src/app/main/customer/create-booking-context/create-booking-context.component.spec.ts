import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateBookingContextComponent } from './create-booking-context.component';

describe('CreateBookingContextComponent', () => {
  let component: CreateBookingContextComponent;
  let fixture: ComponentFixture<CreateBookingContextComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CreateBookingContextComponent]
    });
    fixture = TestBed.createComponent(CreateBookingContextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
