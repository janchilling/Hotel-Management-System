import { Component } from '@angular/core';

@Component({
  selector: 'app-booked-bill-card',
  templateUrl: './booked-bill-card.component.html',
  styleUrls: ['./booked-bill-card.component.scss']
})
export class BookedBillCardComponent {

}
