import { Component } from '@angular/core';

@Component({
  selector: 'app-main-header-navbar',
  templateUrl: './main-header-navbar.component.html',
  styleUrls: ['./main-header-navbar.component.scss']
})
export class MainHeaderNavbarComponent {

  navigateToHome(){
    window.location.href = '/main/home';
  }

}
