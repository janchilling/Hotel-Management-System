import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-confirmation-card',
  templateUrl: './booking-confirmation-card.component.html',
  styleUrls: ['./booking-confirmation-card.component.scss']
})
export class BookingConfirmationCardComponent {

}
