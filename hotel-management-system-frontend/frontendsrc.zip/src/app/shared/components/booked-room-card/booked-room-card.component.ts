import { Component } from '@angular/core';

@Component({
  selector: 'app-booked-room-card',
  templateUrl: './booked-room-card.component.html',
  styleUrls: ['./booked-room-card.component.scss']
})
export class BookedRoomCardComponent {

}
